const bestEducators = [
    {
        "id": 1,
        "image": "images/dicoding.jpg",
        "name": "Dicoding",
        "rating": 3.1,
        "totalCategory": 10,
        "totalCourse": 20,
        "totalLearner": "100K"
    },
    {
        "id": 2,
        "image": "images/yureka-edukasi.jpg",
        "name": "Yureka!",
        "rating": 3.1,
        "totalCategory": 10,
        "totalCourse": 20,
        "totalLearner": "100K"
    },
    {
        "id": 3,
        "image": "images/mahesa-institue.jpg",
        "name": "Mahesa",
        "rating": 3.1,
        "totalCategory": 10,
        "totalCourse": 20,
        "totalLearner": "100K"
    },
    {
        "id": 4,
        "image": "images/sekolah-koding.jpg",
        "name": "Sekolah Koding",
        "rating": 3.1,
        "totalCategory": 10,
        "totalCourse": 20,
        "totalLearner": "100K"
    },
    {
        "id": 5,
        "image": "images/motret.jpg",
        "name": "Motret",
        "rating": 3.1,
        "totalCategory": 10,
        "totalCourse": 20,
        "totalLearner": "100K"
    }
];

module.exports = bestEducators;