const courses = [
    {
        "id": 1,
        "title": "Building Simple Web Using Html Css And Javascripts",
        "image": "images/building-games.jpg",
        "educator": "Alcatera",
        "rating": 4.8,
        "type": "Videos",
        "category": "Technology",
    },
    {
        "id": 2,
        "title": "Fundamental Photography",
        "image": "images/basic-photo.jpg",
        "educator": "Motret",
        "rating": 4.8,
        "type": "Videos",
        "category": "Photography",
    },
    {
        "id": 3,
        "title": "Start Design With Figma",
        "image": "images/basic-design-top.jpg",
        "educator": "Dicoding",
        "rating": 4.8,
        "category": "Design",
    },
    {
        "id": 4,
        "title": "Fundamental Php",
        "image": "images/building-games.jpg",
        "educator": "Alcatera",
        "rating": 4.8,
        "type": "Videos",
        "category": "Technology",
    },
    {
        "id": 5,
        "title": "Basic Photography",
        "image": "images/basic-photo.jpg",
        "educator": "Findapps",
        "rating": 4.8,
        "type": "Videos",
        "category": "Photography",
    },
    {
        "id": 6,
        "title": "Building best ui / ux",
        "image": "images/basic-design-top.jpg",
        "educator": "Travelpedi",
        "rating": 4.8,
        "category": "Design",
    }
];

module.exports = courses;