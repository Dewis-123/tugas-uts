const topStreamer = [
    {
        "id": 1,
        "profileImage": "images/avatar-01.jpg",
        "name": "Dicoding",
        "following": true,
        "verified": true
    },
    {
        "id": 2,
        "profileImage": "images/avatar-01.jpg",
        "name": " Rehan Andika",
        "following": false,
        "verified": false
    },
    {
        "id": 3,
        "profileImage": "images/avatar-01.jpg",
        "name": "Sandhika",
        "following": false,
        "verified": true
    }
];

module.exports = topStreamer;